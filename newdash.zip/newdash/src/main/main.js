import React, {Component} from 'react';
import Abc from '../profit/profit.js';
import Comp from '../compone/compone.js';   
import Range from '../range/range.js';   
import Comptwo from '../comptwo/comptwo.js';
import Img1 from "../assets/images/line.png";
import Img2 from "../assets/images/graph.jpg";
import Img3 from "../assets/images/chart.jpg";
import Dhanu from '../assets/images/dd.jpg';



class main extends Component{
    state={
        title:"Dashboard",
        sub:"Statistics and more",
        one:[
          {header:"PROFIT",value:"$345",desc:"This is testing page",para:"more info",cls:"clr1"},
          {header:"REVENUE",value:"$34.7k",desc:"This is testing page",para:"go to account",cls:"clr2"},
          {header:"MEMBERS",value:"207",desc:"This is testing page",para:"manage member",cls:"clr3"},
          {header:"ORDERS",value:"$345",desc:"This is testing page",para:"manage order",cls:"clr4"}
        ],
            icon:"fas fa-file",
            title1:"Important Shortcuts",
         two:[
             {icon1:"fas fa-calendar-check",name:"Apps"},
             {icon1:"fas fa-file-alt",name:"File"},
             {icon1:"fas fa-signal",name:"Graph"},
             {icon1:"fas fa-comment",name:"Comment"},
             {icon1:"fas fa-user",name:"Users"},
             {icon1:"fas fa-sticky-note",name:"Notes"},
             {icon1:"far fa-image",name:"Photos"},
             {icon1:"fas fa-tag",name:"Tags"}
           ],
           three:[
               {header1:"Friday $ 48,00 | 13%", photo:Img1},
               {header1:"June 18 Days | 55%", photo:Img2},
               {header1:"Total $ In | 100%", photo:Img3},
              
           ],
           name1:"Description",
           icon2:"fas fa-cloud",
           am:"68A",

           four:[
            {nm1:"Orders",per:"upto50%"},
            {nm1:"Stock",per:"30In%"},
            {nm1:"Pending",per:"20%"}
           ],
           pic1:Dhanu,
           name2:"Dhananjay Nevase",
           pro:"UI Developer",
           add:"Gujrath Colony, Kothrud, Pune",
           pincode:"PinCode : 411038"

        }
        render(){
            return(
                <div className="container">
                    <h1>{this.state.title }</h1>
                    <h5>{this.state.sub}</h5>
                     <div>
                         <Abc hdr={this.state.one[0].header} num={this.state.one[0].value}src={this.state.one[0].brd}desc={this.state.one[0].desc} para={this.state.one[0].para} clr={this.state.one[0].cls}></Abc>
                    
                         <Abc hdr={this.state.one[1].header} num={this.state.one[1].value}src={this.state.one[1].brd}desc={this.state.one[1].desc} para={this.state.one[1].para} clr={this.state.one[1].cls}></Abc>
                    
                         <Abc hdr={this.state.one[2].header} num={this.state.one[2].value}src={this.state.one[2].brd}desc={this.state.one[2].desc} para={this.state.one[2].para} clr={this.state.one[2].cls}></Abc>
                    
                         <Abc hdr={this.state.one[3].header} num={this.state.one[3].value}src={this.state.one[3].brd}desc={this.state.one[3].desc} para={this.state.one[3].para} clr={this.state.one[3].cls}></Abc>
                     </div>
                     <div className="main">
                        <div className="subfea">
                            <div className="middle">
                                <i className={this.state.icon}></i>
                                <h3>{this.state.title1}</h3>
                            </div>
                            <div className="fff">
                                <Comp ic1={this.state.two[0].icon1} hd1={this.state.two[0].name}></Comp>
                                <Comp ic1={this.state.two[1].icon1} hd1={this.state.two[1].name}></Comp>
                                <Comp ic1={this.state.two[2].icon1} hd1={this.state.two[2].name}></Comp>
                                <Comp ic1={this.state.two[3].icon1} hd1={this.state.two[3].name}></Comp>
                                <Comp ic1={this.state.two[4].icon1} hd1={this.state.two[4].name}></Comp>
                                <Comp ic1={this.state.two[5].icon1} hd1={this.state.two[5].name}></Comp>
                                <Comp ic1={this.state.two[6].icon1} hd1={this.state.two[6].name}></Comp>
                                <Comp ic1={this.state.two[7].icon1} hd1={this.state.two[7].name}></Comp>
                            </div>
                            
                        </div>
                        <div>
                            <div className="submain">
                                <h3>{this.state.name1}</h3>
                                <i className={this.state.icon2}></i>
                                <span>{this.state.am}</span>
                                <div className="sss">
                                <div className="subft">
                                     <Comptwo nav={this.state.four[0].nm1} val={this.state.four[0].per}></Comptwo>
                                     <Comptwo nav={this.state.four[1].nm1} val={this.state.four[1].per}></Comptwo>
                                     <Comptwo nav={this.state.four[2].nm1} val={this.state.four[2].per}></Comptwo>
                                </div>
                                </div>
                                <div className="profile">
                                    <img src={Dhanu}width="31%"height="auto"/>
                                    <h4>{this.state.name2}</h4>
                                    <h6><u><a href="#.">{this.state.pro}</a></u></h6>
                                    <p>{this.state.add}</p>
                                    <p>{this.state.pincode}</p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                     <div>
                         <Range nme={this.state.three[0].header1} path={this.state.three[0].photo}></Range>
                         <Range nme={this.state.three[1].header1} path={this.state.three[1].photo}></Range>
                         <Range nme={this.state.three[2].header1} path={this.state.three[2].photo}></Range>
                         
                     </div>
                </div>
                 )
                     }
    }
export default main;
import React,{Component}from 'react';
import './comptwo.css';

const comptwo=(props)=>{
    return(
        <div className="subpart">
            <h5>{props.nav}</h5>
            <span>{props.val}</span>
        </div>
    )
}
export default comptwo;
import React,{Component}from 'react';
import './profit.css';


const profit=(props)=>{
    return(
        <div className="aaa">
            <h4>{props.hdr}</h4>
            <div className={props.clr}>
                
                <span>{props.num}</span>
                <p>{props.desc}</p>
                
            </div>
            <p><a href="#.">{props.para}</a></p>
        </div>)
}
export default profit;
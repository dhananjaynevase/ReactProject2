import React,{Component}from 'react';
import './compone.css';

const comp=(props)=>{
    return(
                
                <div className="aside">
                    <i className={props.ic1}></i>
                    <h3>{props.hd1}</h3>
                </div>

    )
}
export default comp;
import React,{Component}from 'react';
import './range.css';

const range=(props)=>{
    return(
        <div className="footer">
            <span>{props.nme}</span>
            <img src={props.path} width="90%" height="auto"></img>
        </div>
    )
}
export default range;
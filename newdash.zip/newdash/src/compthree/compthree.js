import React,{Component}from 'react';
import './comptwo.css';

const compthree=(props)=>{
    return(
        <div className="subpart">
            <h5>{props.nav}</h5>
            <span>{props.val}</span>
        </div>
    )
}
export default compthree;